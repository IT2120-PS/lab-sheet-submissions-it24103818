setwd ("C:\\Users\\abish\\OneDrive - Sri Lanka Institute of Information Technology\\Desktop\\IT24103818_Lab6")


#EXERCISE

#Question 01

#Part 1
#Binomial Distribution
#Random variable x has binomial distribution with n=50 and p=0.85

#Part 2
pbinom(46, 50, 0.85, lower.tail = FALSE)


#Question 02

#Part 1
#Number of calls in an hour

#Part 2
#Poisson Distribution
#Random variable X has poisson distribution with lambda=12

#Part 3
dpois(15, 12)